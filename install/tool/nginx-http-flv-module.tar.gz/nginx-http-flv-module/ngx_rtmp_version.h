
/*
 * Copyright (C) Roman Arutyunyan
 * Copyright (C) Winshining
 */


#ifndef _NGX_RTMP_VERSION_H_INCLUDED_
#define _NGX_RTMP_VERSION_H_INCLUDED_


#define nginx_rtmp_version  1002006
#define NGINX_RTMP_VERSION  "1.2.6"


#endif /* _NGX_RTMP_VERSION_H_INCLUDED_ */
