
/*
 * Copyright (C) Roman Arutyunyan
 */


#ifndef _NGX_RTMP_VERSION_H_INCLUDED_
#define _NGX_RTMP_VERSION_H_INCLUDED_


#define nginx_rtmp_version  1001007
#define NGINX_RTMP_VERSION  "1.1.7.11-dev"


#endif /* _NGX_RTMP_VERSION_H_INCLUDED_ */
